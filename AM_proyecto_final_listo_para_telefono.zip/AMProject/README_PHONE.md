# A'M — compilación desde el teléfono

Este proyecto es independiente de la aplicación original (`com.am.app`).

## Generar APK desde GitHub Actions
1. Crea un repositorio nuevo en GitHub.
2. Sube **todo el contenido de esta carpeta** al repositorio, incluyendo `.github/workflows/build-apk.yml`.
3. En GitHub abre **Actions → Build A'M APK → Run workflow**.
4. Cuando termine correctamente, abre la ejecución y descarga el artefacto **AM-debug-apk**.
5. Extrae el ZIP y toca `app-debug.apk` para instalarlo.

El APK es una versión debug para pruebas. No modifica ni reemplaza la aplicación original mientras uses el mismo dispositivo con paquetes diferentes.
