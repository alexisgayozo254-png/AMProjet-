package com.am.app;
public class CatalogItem {
  public final String title, category, description, url;
  public CatalogItem(String title,String category,String description,String url){this.title=title;this.category=category;this.description=description;this.url=url;}
}
