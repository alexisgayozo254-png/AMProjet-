package com.am.app;
import java.util.*;
public final class Catalog {
  private Catalog(){}
  public static List<CatalogItem> items(){
    List<CatalogItem> x=new ArrayList<>();
    String demo="https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";
    x.add(new CatalogItem("Big Buck Bunny","Películas","Contenido de demostración para probar el reproductor de A’M.",demo));
    x.add(new CatalogItem("Elephants Dream","Películas","Ejemplo de reproducción en alta calidad.","https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"));
    x.add(new CatalogItem("For Bigger Blazes","Series","Elemento de demostración del catálogo.","https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"));
    return x;
  }
}
