package com.am.app;
import android.content.*;import java.util.*;
public final class Favorites {
 private Favorites(){}
 private static final String PREF="favorites";
 public static boolean has(Context c,String title){return c.getSharedPreferences(PREF,0).getBoolean(title,false);}
 public static void toggle(Context c,String title){get(c).edit().putBoolean(title,!has(c,title)).apply();}
 public static List<CatalogItem> list(Context c){List<CatalogItem> r=new ArrayList<>();for(CatalogItem i:Catalog.items())if(has(c,i.title))r.add(i);return r;}
 private static android.content.SharedPreferences get(Context c){return c.getSharedPreferences(PREF,0);}
}
