package com.am.app;
import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.widget.*;import androidx.media3.common.MediaItem;import androidx.media3.exoplayer.ExoPlayer;import androidx.media3.ui.PlayerView;
public class PlayerActivity extends Activity{
 ExoPlayer player; String url;
 public void onCreate(Bundle b){super.onCreate(b);url=getIntent().getStringExtra("url");if(url==null)url="https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";PlayerView pv=new PlayerView(this);pv.setBackgroundColor(Color.BLACK);setContentView(pv);player=new ExoPlayer.Builder(this).build();pv.setPlayer(player);player.setMediaItem(MediaItem.fromUri(url));player.prepare();player.play();}
 protected void onStop(){super.onStop();if(player!=null)player.pause();}
 protected void onDestroy(){if(player!=null){player.release();player=null;}super.onDestroy();}
}
