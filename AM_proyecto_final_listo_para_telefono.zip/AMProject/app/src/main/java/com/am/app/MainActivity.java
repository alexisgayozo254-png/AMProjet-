package com.am.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.view.inputmethod.EditorInfo;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
  LinearLayout content; EditText search; final List<CatalogItem> all=Catalog.items();
  int white=Color.rgb(245,245,247), muted=Color.rgb(165,166,173), bg=Color.rgb(10,11,14), panel=Color.rgb(22,24,29), accent=Color.rgb(255,92,92);
  @Override public void onCreate(Bundle b){super.onCreate(b);showHome();}
  TextView tv(String s,float sp){TextView v=new TextView(this);v.setText(s);v.setTextColor(white);v.setTextSize(sp);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
  TextView pill(String s){TextView v=tv(s,13);v.setGravity(Gravity.CENTER);v.setTextColor(white);GradientDrawable g=new GradientDrawable();g.setColor(panel);g.setCornerRadius(50);v.setBackground(g);v.setPadding(28,0,28,0);return v;}
  void shell(){
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
    LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(20,10,14,4);
    TextView logo=tv("A’M",27);logo.setTypeface(Typeface.DEFAULT,Typeface.BOLD);bar.addView(logo,new LinearLayout.LayoutParams(0,62,1));
    TextView q=tv("⌕",29);q.setGravity(Gravity.CENTER);bar.addView(q,new LinearLayout.LayoutParams(58,62));q.setOnClickListener(v->showSearch());root.addView(bar);
    ScrollView sv=new ScrollView(this);sv.setFillViewport(true);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,0,0,22);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout nav=new LinearLayout(this);nav.setPadding(8,5,8,8);nav.setBackgroundColor(Color.rgb(15,16,20));String[] ns={"⌂\nInicio","▣\nPelículas","▤\nSeries","♡\nFavoritos"};for(String n:ns){TextView x=tv(n,12);x.setGravity(Gravity.CENTER);nav.addView(x,new LinearLayout.LayoutParams(0,66,1));final String key=n; x.setOnClickListener(v->{if(key.contains("Inicio"))showHome();else if(key.contains("Favoritos"))showFavorites();else showCategory(key.contains("Películas")?"Películas":"Series");});}root.addView(nav);setContentView(root);
  }
  void showHome(){shell();
    TextView hero=tv("A’M\nTu entretenimiento, simple.",28);hero.setTypeface(Typeface.DEFAULT,Typeface.BOLD);hero.setPadding(22,22,22,10);content.addView(hero,new LinearLayout.LayoutParams(-1,150));
    TextView sub=tv("Encuentra algo para ver y empieza con un toque.",14);sub.setTextColor(muted);sub.setPadding(22,0,22,18);content.addView(sub);
    LinearLayout chips=new LinearLayout(this);chips.setPadding(16,0,16,18);TextView m=pill("Películas");TextView s=pill("Series");chips.addView(m,new LinearLayout.LayoutParams(0,46,1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,46,1);sp.setMargins(10,0,0,0);chips.addView(s,sp);m.setOnClickListener(v->showCategory("Películas"));s.setOnClickListener(v->showCategory("Series"));content.addView(chips);
    section("Destacados",all); }
  void section(String name,List<CatalogItem> list){TextView h=tv(name,21);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setPadding(20,14,20,8);content.addView(h);for(CatalogItem i:list)card(i);}
  void card(CatalogItem i){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(18,10,18,10);GradientDrawable g=new GradientDrawable();g.setColor(panel);g.setCornerRadius(22);c.setBackground(g);
    TextView t=tv(i.title,17);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(t,new LinearLayout.LayoutParams(-1,38));TextView d=tv(i.category+"  •  "+i.description,13);d.setTextColor(muted);c.addView(d,new LinearLayout.LayoutParams(-1,38));
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,88);p.setMargins(16,5,16,8);content.addView(c,p);c.setOnClickListener(v->open(i));}
  void open(CatalogItem i){startActivity(new Intent(this,DetailActivity.class).putExtra("title",i.title).putExtra("category",i.category).putExtra("description",i.description).putExtra("url",i.url));}
  void showCategory(String cat){shell();section(cat,filter(cat));}
  List<CatalogItem> filter(String cat){List<CatalogItem> r=new ArrayList<>();for(CatalogItem i:all)if(i.category.equals(cat))r.add(i);return r;}
  void showFavorites(){shell();content.addView(tv("Mis favoritos",26));List<CatalogItem> r=Favorites.list(this);if(r.isEmpty())content.addView(tv("Guarda títulos para encontrarlos aquí.",14));else section("Guardados",r);}
  void showSearch(){shell();content.addView(tv("Buscar",25));search=new EditText(this);search.setHint("Película, serie o categoría");search.setHintTextColor(Color.rgb(120,121,128));search.setTextColor(white);search.setSingleLine(true);search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);search.setPadding(18,0,18,0);GradientDrawable g=new GradientDrawable();g.setColor(panel);g.setCornerRadius(20);search.setBackground(g);content.addView(search,new LinearLayout.LayoutParams(-1,58));Button b=new Button(this);b.setText("Buscar");content.addView(b,new LinearLayout.LayoutParams(-1,52));b.setOnClickListener(v->doSearch());search.setOnEditorActionListener((v,a,e)->{doSearch();return true;});}
  void doSearch(){String q=search.getText().toString().trim().toLowerCase();while(content.getChildCount()>3)content.removeViewAt(3);List<CatalogItem> r=new ArrayList<>();for(CatalogItem i:all)if(i.title.toLowerCase().contains(q)||i.category.toLowerCase().contains(q)||i.description.toLowerCase().contains(q))r.add(i);section(r.isEmpty()?"Sin resultados":"Resultados",r);}
}
