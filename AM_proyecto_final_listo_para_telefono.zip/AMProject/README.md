# A’M 1.3

Recreación independiente de la app de referencia, con diseño moderno y simplificado.

## Incluye
- Inicio, películas, series, favoritos y búsqueda.
- Detalle y reproducción de contenido.
- Media3 1.11.0 para reproducción local/remota y HLS.
- Catálogo de demostración en `app/src/main/assets/catalog.json`.

## Importante
El catálogo de demostración usa URLs públicas de prueba. No contiene ni extrae contenido protegido de la APK original. Para producción hay que conectar una API/servidor sobre el que tengas autorización.

## Compilar
Abrir `AMProject` en Android Studio actualizado y ejecutar **Build > Build APK(s)**. El APK de depuración quedará en `app/build/outputs/apk/debug/`.
